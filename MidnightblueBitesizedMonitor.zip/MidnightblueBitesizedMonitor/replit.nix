{pkgs}: {
  deps = [
    pkgs.python312Packages.flit
    pkgs.please
    pkgs.freetype
    pkgs.glibcLocales
  ];
}

import io
import os
from datetime import datetime

import pandas as pd
from flask import (
    Flask,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from replit import db

# from io import BytesIO
# from reportlab.pdfgen import canvas
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = os.urandom(24)


@app.route('/')
def index():
    if 'user_id' in session:
        user_id = session['user_id']
        user_group_id = db[f"user_{user_id}"]['group_id']
        all_players = db.get("players", [])
        players = [
            p for p in all_players if p.get('group_id') == user_group_id
        ]

        categories = {
            "Under 14": [],
            "Under 15": [],
            "Under 16": [],
            "Under 19": [],
        }

        for player in players:

            dob = datetime.strptime(player['dob'], '%d/%m/%Y')
            age = (datetime.now() - dob).days // 365
            if age < 14:
                categories["Under 14"].append(player)
            if age < 15:
                categories["Under 15"].append(player)
            elif age < 16:
                categories["Under 16"].append(player)
            elif age < 19:
                categories["Under 19"].append(player)
            else:
                print("bruh")

        return render_template('todos.html', categories=categories, db=db)
    return redirect(url_for('login'))


@app.route('/delete_player', methods=['POST'])
def delete_player():
    if 'user_id' in session:
        user_id = session['user_id']
        user_group_id = db[f"user_{user_id}"]['group_id']
        name = request.form.get('name')
        if name:
            players = db.get("players", [])
            players = [
                p for p in players
                if not (p['name'] == name and p['group_id'] == user_group_id)
            ]
            db["players"] = players
    return redirect(url_for('index'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user_key = f"user_{username}"
        if user_key in db and check_password_hash(db[user_key]['password'],
                                                  password):
            user_data = db[user_key]
            if 'group_id' not in user_data:
                flash('Account data corrupted..', 'error')
                return render_template('login.html')
            session['user_id'] = username
            session['username'] = username
            flash('Successfully logged in!', 'success')
            return redirect(url_for('index'))
        flash('Invalid username or password', 'error')
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('register.html')

        user_key = f"user_{username}"
        if user_key in db:
            flash('Username already exists', 'error')
            return render_template('register.html')

        group_id = request.form['group_id'].upper()
        if len(group_id) != 3 or not group_id.isalpha():
            flash('Group ID must be 3 letters', 'error')
            return render_template('register.html')

        db[user_key] = {
            'password': generate_password_hash(password),
            'group_id': group_id
        }
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/toggle_event', methods=['POST'])
def toggle_event():
    if 'user_id' in session:
        user_id = session['user_id']
        player_name = request.form.get('player_name')
        event_name = request.form.get('event_name')
        is_checked = request.form.get('is_checked') == 'true'

        players = db.get(f"players_{user_id}", [])
        for player in players:
            if player['name'] == player_name:
                if 'events' not in player:
                    player['events'] = {}
                player['events'][event_name] = is_checked
                break

        db[f"players_{user_id}"] = players
        return 'OK'
    return 'Unauthorized', 401


@app.route('/add_player', methods=['POST'])
def add_player():
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    dob = request.form.get('dob')
    player_group_id = request.form.get('player_group_id')
    if player_group_id:
        player_group_id = player_group_id.upper()
    if first_name and last_name and dob and player_group_id:
        if len(player_group_id) != 3 or not player_group_id.isalpha():
            flash('Group ID must be 3 letters', 'error')
            return redirect(url_for('login'))
        players = db.get("players", [])
        players.append({
            "first_name": first_name,
            "last_name": last_name,
            "name": f"{last_name}, {first_name}",
            "dob": dob,
            "group_id": player_group_id
        })
        db["players"] = players
        flash('Player added successfully!', 'success')
    return redirect(url_for('login'))


@app.route('/delete_all_data', methods=['POST'])
def delete_all_data():
    db.clear()
    flash('All data deleted!', 'success')
    return redirect(url_for('login'))


@app.route('/get_csv', methods=['POST'])
def get_csv():
    f = request.files.get('csv')
    if f:
        try:
            content = f.read().decode('utf-8').splitlines()
            current_players = db.get("players", [])

            data_rows = content[5:]

            for row in data_rows:
                cols = [col.strip() for col in row.split(',')]
                if len(cols) < 4:
                    continue

                first_name = cols[1]
                last_name = cols[0]
                group_id = cols[2]
                age_group = cols[3]

                if not all([first_name, last_name, group_id, age_group]):
                    continue

                player = {
                    "first_name": first_name,
                    "last_name": last_name,
                    "name": f"{last_name}, {first_name}",
                    "dob": calculate_dob_from_age_group(age_group),
                    "group_id": group_id,
                    "events": {}
                }

                event_map = {
                    'A': '100m',
                    'B': '200m',
                    'C': '400m',
                    'D': '800m',
                    'E': '1500m',
                    'F': '3000m',
                    'G': 'DIS',
                    'H': 'HJ',
                    'I': 'TJ',
                    'J': 'JAV',
                    'K': 'SHOT',
                    'L': 'LJ',
                    'M': '80H',
                    'N': '100H',
                    'O': 'Softball',
                    'P': 'U19_Pent'
                }

                for idx, letter in enumerate('ABCDEFGHIJKLMNOP'):
                    col_idx = idx + 4
                    if col_idx < len(cols) and cols[col_idx] == letter:
                        player['events'][event_map[letter]] = 'on'

                current_players.append(player)

            db["players"] = current_players
            flash('CSV data imported successfully!', 'success')

        except Exception as e:
            print(f"Error reading CSV: {e}")
            flash('Error processing CSV file', 'error')
            return redirect(url_for('login'))

    return redirect(url_for('login'))


def calculate_dob_from_age_group(age_group):
    age = int(age_group.split()[1])
    birth_year = 2025 - age
    return f"01/07/{birth_year}"


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/save_selections', methods=['POST'])
def save_selections():
    if 'user_id' in session:
        user_id = session['user_id']
        user_group_id = db[f"user_{user_id}"]['group_id']
        players = db.get("players", [])
        for player in players:
            player_name = player['name']
            if player['group_id'] == user_group_id:
                events = {}
                for event in [
                        '100m', '200m', '400m', '800m', '1500m', '3000m',
                        'DIS', 'HJ', 'TJ', 'JAV', 'SHOT', 'LJ', '80H', '100H',
                        'Softball', 'U19_Pent'
                ]:
                    is_checked = request.form.get(f'{player_name}_{event}',
                                                  None)
                    events[event] = is_checked
                player['events'] = events
        db["players"] = players
        return redirect(url_for('index'))
    return 'Unauthorized', 401


@app.route('/download')
def downloadFile():
    csv_data = generate_csv_file()
    binary_data = io.BytesIO()
    binary_data.write(csv_data.getvalue().encode('utf-8'))
    binary_data.seek(0)
    return send_file(binary_data,
                     mimetype='text/csv',
                     as_attachment=True,
                     download_name='formatted.csv')


@app.route('/booklet')
def booklet():
    all_players = db.get("players", [])
    age_groups = ["Under 14", "Under 15", "Under 16", "Under 19"]
    events = ['Hurdles', '100m', '200m', '400m', '800m', '1500m', '3000m']

    organized_heats = {}

    for age in age_groups:
        organized_heats[age] = {}
        for event in events:
            qualified_players = []
            for player in all_players:
                player_age = get_age_group(player['dob'])
                if event == 'Hurdles':
                    if player_age == age and (
                            player.get('events', {}).get('80H')
                            or player.get('events', {}).get('100H')):
                        qualified_players.append(player)
                elif player_age == age and player.get('events', {}).get(event):
                    qualified_players.append(player)

            if event == 'Hurdles':
                qualified_players.sort(key=lambda x: x['last_name'])

            heats = []
            if qualified_players:
                for i in range(0, len(qualified_players), 6):
                    current_heat = qualified_players[i:i + 6]
                    if len(current_heat) == 1 and heats:
                        heats[-1].extend(current_heat)
                    else:
                        heats.append(current_heat)

                if heats: 
                    organized_heats[age][event] = heats

    return render_template('booklet.html', organized_heats=organized_heats)


def generate_csv_file():
    output = io.StringIO()
    output.write(',,,,,,,2025 EVENTS,,,,,,,,,,,,,\n')
    output.write(',,,,,,,,,,open,,,open,,,,,,,\n')
    output.write(',,,,,,TRACK,,,,,,,FIELD,,,,,,\n')
    output.write('NAME,,,Age,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P\n')
    output.write(
        'Last,First,Group,Group,100,200,400,800,1500,3000,DIS,HJ,TJ,JAV,SHOT,LJ,80H,100H,Softball,U19 Pent\n'
    )

    players = db.get("players", [])
    sorted_players = sorted(
        players,
        key=lambda x: (["Under 14", "Under 15", "Under 16", "Under 19"].index(
            get_age_group(x['dob'])), x['last_name'], x['first_name']))

    for player in sorted_players:
        events = player.get('events', {})
        row = [
            player['last_name'], player['first_name'],
            player.get('group_id', ''),
            get_age_group(player['dob']), 'A' if events.get('100m') else '',
            'B' if events.get('200m') else '',
            'C' if events.get('400m') else '',
            'D' if events.get('800m') else '',
            'E' if events.get('1500m') else '',
            'F' if events.get('3000m') else '',
            'G' if events.get('DIS') else '', 'H' if events.get('HJ') else '',
            'I' if events.get('TJ') else '', 'J' if events.get('JAV') else '',
            'K' if events.get('SHOT') else '', 'L' if events.get('LJ') else '',
            'M' if events.get('80H') else '',
            'N' if events.get('100H') else '',
            'O' if events.get('Softball') else '',
            'P' if events.get('U19_Pent') else ''
        ]
        output.write(','.join(row) + '\n')

    output.seek(0)
    return output


def get_age_group(dob_str):
    dob = datetime.strptime(dob_str, '%d/%m/%Y')
    age = (datetime.now() - dob).days // 365
    if age < 14:
        return "Under 14"
    elif age < 15:
        return "Under 15"
    elif age < 16:
        return "Under 16"
    elif age < 19:
        return "Under 19"
    return "Over 19"


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

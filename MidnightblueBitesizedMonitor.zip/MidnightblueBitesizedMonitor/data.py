import pandas as pd

# Creating the data as a dictionary
data = {
    "First Name": [
        "James", "Amir", "Juan", "Hiroshi", "Mohammed", "Chen", "Raj", "Ahmed",
        "Lucas", "Rafael"
    ],
    "Last Name": [
        "O'Connor", "Khan", "Garcia", "Tanaka", "Al-Farsi", "Li", "Patel",
        "Al-Mansoor", "Pereira", "Silva"
    ],
    "DOB": [
        "12/05/2007", "03/08/2008", "24/11/2009", "14/02/2007", "19/06/2008",
        "27/07/2009", "09/03/2010", "05/12/2007", "16/01/2008", "22/09/2009"
    ],
    "Group ID":
    ["SYP", "SSH", "SCY", "TDR", "SYP", "SSH", "SCY", "TDR", "SYP", "SSH"]
}

# Creating a DataFrame
df = pd.DataFrame(data)

# Saving the DataFrame to CSV
csv_file_path = "./data.csv"
df.to_csv(csv_file_path, index=False)

csv_file_path
